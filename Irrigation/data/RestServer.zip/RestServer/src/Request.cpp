#include "Request.h"
#include "Webserver.h"
#include "Logger.h"


Request::Request(MHD_Connection* connection, const char* version, const char* method, const char* url, const Data& uploadData) :
	connection(connection),
	url(url),
	method(method),
	version(version),
	uploadData(uploadData),
	parameters()
{
}

const Parameters& Request::getRequestParameters() const {
	if (nullptr == parameters.get()) {
		const_cast<std::unique_ptr<Parameters>&>(parameters).reset(new Parameters());

		if (nullptr != connection) {
			MHD_get_connection_values(connection, MHD_GET_ARGUMENT_KIND, iterateOnGetParameters, parameters.get());
		}
	}

	return *parameters;
}

int Request::iterateOnGetParameters(void *cls, enum MHD_ValueKind kind, const char *key, const char *value) {
	LOGGER.trace("Request parameter: \"%s\" - \"%s\"", key, value);

	Parameters* parameters = static_cast<Parameters*>(cls);
	parameters->insert(std::make_pair(std::string(key), std::string(value)));
	return MHD_YES;
}

