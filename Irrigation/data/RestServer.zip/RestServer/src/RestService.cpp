#include "RestService.h"

#include <iostream>
#include <sstream>
#include <stdexcept>

#include "Response.h"
#include "WebServerException.h"

#include <iostream>


RestService::RestService() {
	// TODO Auto-generated constructor stub
}

RestService::~RestService() {
	// TODO Auto-generated destructor stub
}

Response* RestService::onRequest(const Request& request) {

	Path requestPath;
	PathTemplate::split(request.getUrl(), requestPath);

	bool pathFound = false;

	PathInfos::const_iterator it;
	for (it = pathInfos.begin(); pathInfos.end() != it; ++it) {

		const PathInfo& pathInfo = it->second;
		Parameters parameters;

		if (pathInfo.path->evaluate(requestPath, parameters)) {
			pathFound = true;

			const RestServiceCallback* restServiceCallback = findCallback(pathInfo.callbacks, request.getMethod());
			if (restServiceCallback) {
				return restServiceCallback->operator() (request, parameters);
			}
		}
	}

	if (pathFound) {
		throw WebServerException(MHD_HTTP_METHOD_NOT_ALLOWED);
	} else {
		throw WebServerException(MHD_HTTP_NOT_FOUND);
	}
}

const RestServiceCallback* RestService::findCallback(const Callbacks& callbacks, const std::string& method) {
	Callbacks::const_iterator it = callbacks.find(method);

	if (callbacks.end() == it) {
		return NULL;
	}

	return &(it->second);
}

void RestService::addPath(const std::string& method, const std::string& path, RestServiceCallback restServiceCallback) {
	Callbacks& callbacks = getCallbacks(path);
	callbacks.insert(std::make_pair(method, restServiceCallback));
}

RestService::Callbacks& RestService::getCallbacks(const std::string& path) {
	PathInfos::iterator it = pathInfos.find(path);

	if (pathInfos.end() == it) {
		it = pathInfos.insert(std::make_pair(path, PathInfo(new PathTemplate(path)))).first;
	}

	return it->second.callbacks;
}
