#pragma once
#include <stdexcept>


class WebServerException : public std::runtime_error {
	unsigned statusCode;

public:
	WebServerException(int statusCode) :
		std::runtime_error(""),
		statusCode(statusCode)
	{}

	unsigned getStatusCode() const { return statusCode; }
};
