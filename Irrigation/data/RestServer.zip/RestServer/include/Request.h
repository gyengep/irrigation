#pragma once
#include <map>
#include <memory>
#include <microhttpd.h>
#include <string>
#include <vector>

typedef std::map<std::string, std::string> Parameters;
typedef std::vector<char> Data;


class Request {
	MHD_Connection* connection;
	const std::string url;
	const std::string method;
	const std::string version;
	const Data& uploadData;
	std::unique_ptr<Parameters> parameters;

	// disable copy constructor and operator
	Request(const Request&);
	const Request& operator= (const Request&);

	static int iterateOnGetParameters(void *cls, enum MHD_ValueKind kind, const char *key, const char *value);

public:
	Request(MHD_Connection* connection, const char* version, const char* method, const char *url,
			const Data& uploadData);

	const std::string& getUrl() const { return url; }
	const std::string& getMethod() const { return method; }
	const std::string& getVersion() const { return version; }
	const Data& getUploadData() const { return uploadData; }
	const Parameters& getRequestParameters() const;
};
