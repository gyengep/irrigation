#pragma once
#include <map>
#include "PathTemplate.h"
#include "Request.h"
#include "Response.h"
#include "WebServer.h"

typedef std::function<Response*(const Request& request, const Parameters& pathParameters)> RestServiceCallback;


class RestService : public WebService {

	typedef std::map<const std::string, RestServiceCallback> Callbacks;

	struct PathInfo {
		std::unique_ptr<PathTemplate> path;
		Callbacks callbacks;

		PathInfo(PathTemplate* path) : path(path) {}
	};

	typedef std::map<const std::string, PathInfo> PathInfos;

	PathInfos pathInfos;

	Callbacks& getCallbacks(const std::string& path);
	static const RestServiceCallback* findCallback(const Callbacks& callbacks, const std::string& method);

public:
	RestService();
	virtual ~RestService();

	virtual Response* onRequest(const Request& request);
	void addPath(const std::string& method, const std::string& path, RestServiceCallback restServiceCallback);
};
