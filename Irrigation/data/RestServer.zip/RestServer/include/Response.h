#pragma once
#include <microhttpd.h>
#include <string>

class Request;
class WebServer;


class Response {

	const std::string message;
	const unsigned statusCode;

	// disable copy constructor and operator
	Response(const Response&);
	const Response& operator= (const Response&);

public:
	Response(const std::string& message, int statusCode = MHD_HTTP_OK) :
		message(message),
		statusCode(statusCode)
	{
	}

	const std::string& getMessage() const { return message; }
	unsigned getStatusCode() const { return statusCode; }
};
