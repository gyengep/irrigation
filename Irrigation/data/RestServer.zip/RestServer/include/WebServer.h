#pragma once
#include <microhttpd.h>
#include <map>
#include <memory>
#include <string>
#include <vector>

class Response;
class Request;


class WebService {
public:
	virtual Response* onRequest(const Request& request) = 0;
};

class WebServer {
	static int accessHandlerCallback(void *cls, struct MHD_Connection *connection,
		const char *url, const char *method, const char *version,
		const char *upload_data, size_t *upload_data_size, void **con_cls);

	static void onFatalError(void *cls, const char *file, unsigned int line, const char *reason);

	static std::map<int, std::string> errorMessages;

	struct MHD_Daemon *daemon;

	static std::string getErrorMessage(int errorCode);
	static std::string getErrorPage(int errorCode);

	static int sendResponse(struct MHD_Connection* connection, const std::string& message, unsigned statusCode);

public:
	WebServer(WebService* webService, uint16_t port);
	virtual ~WebServer();

};
