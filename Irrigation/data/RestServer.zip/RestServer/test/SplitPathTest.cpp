#include "SplitPathTest.h"
#include "PathTemplate.h"
#include <stdexcept>


void SplitPathTest::SetUp() {
}

void SplitPathTest::TearDown() {
}

TEST_F(SplitPathTest, validOrNot) {
	Path path;

	EXPECT_THROW(PathTemplate::split("", path), invalid_argument);
	EXPECT_NO_THROW(PathTemplate::split("/", path));
	EXPECT_THROW(PathTemplate::split("//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123//", path), invalid_argument);
	EXPECT_NO_THROW(PathTemplate::split("/123", path));
	EXPECT_THROW(PathTemplate::split("/123/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("/123//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123/abcef", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123/abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123/abcef//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123//abcef", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123//abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("123//abcef//", path), invalid_argument);
	EXPECT_NO_THROW(PathTemplate::split("/123/abcef", path));
	EXPECT_THROW(PathTemplate::split("/123/abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("/123/abcef//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("/123//abcef", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("/123//abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("/123//abcef//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123/abcef", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123/abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123/abcef//", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123//abcef", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123//abcef/", path), invalid_argument);
	EXPECT_THROW(PathTemplate::split("//123//abcef//", path), invalid_argument);
}

TEST_F(SplitPathTest, vaildPath1) {
	Path path;
	PathTemplate::split("/", path);
	EXPECT_EQ(Path(), path);
}

TEST_F(SplitPathTest, vaildPath2) {
	Path path;
	PathTemplate::split("/abcde", path);
	EXPECT_EQ(Path{"abcde"}, path);
}

TEST_F(SplitPathTest, vaildPath3) {
	Path path;
	PathTemplate::split("/XY/qwert", path);
	EXPECT_EQ(Path({"XY", "qwert"}), path);
}

