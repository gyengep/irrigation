#pragma once
#include <gtest/gtest.h>
#include "Response.h"
#include "Request.h"
#include "WebServer.h"

using namespace std;


class WebServerTest : public ::testing::Test {
protected:

	class TestWebService : public WebService {
	public:
		TestWebService();

		string lastRequestedUrl;
		string lastRequestedMethod;
		string lastRequestedVersion;
		Parameters lastRequestedParameters;
		Data lastRequestedData;

		string httpResponse;
		int httpResponseCode;

		virtual Response* onRequest(const Request& request);
	};

	typedef string DownloadDataType;
	typedef pair<size_t, const char*> UploadDataType;

	const uint16_t port = 8080;
	unique_ptr<TestWebService> testWebService;
	unique_ptr<WebServer> webServer;

    virtual void SetUp();
    virtual void TearDown();

public:
	static string createUrl(uint16_t port, const string& path, const Parameters& parameters);
	static size_t dataArrived(void* buffer, size_t size, size_t nmemb, void* ctxt);
	static size_t dataRequested(void* buffer, size_t size, size_t nmemb, void* ctxt);
};
