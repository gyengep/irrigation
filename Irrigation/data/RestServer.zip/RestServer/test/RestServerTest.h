#pragma once
#include <gmock/gmock.h>
#include "RestService.h"
#include "WebServer.h"

using namespace std;


class RestServerTest : public ::testing::Test {
protected:

	const uint16_t port = 8080;
	unique_ptr<RestService> restService;
	unique_ptr<WebServer> webServer;

    virtual void SetUp();
    virtual void TearDown();

public:
	MOCK_METHOD2(onCreateProgram, Response*(const Request& request, const Parameters& pathParameters));
	MOCK_METHOD2(onGetProgram, Response*(const Request& request, const Parameters& pathParameters));
};
