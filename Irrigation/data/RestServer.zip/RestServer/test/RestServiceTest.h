#pragma once
#include <gmock/gmock.h>
#include "RestService.h"
#include "Request.h"
#include "Response.h"

using namespace std;


class RestServiceTest : public ::testing::Test {
protected:

	RestService restService;

    virtual void SetUp();
    virtual void TearDown();

public:
	MOCK_METHOD2(callback1, Response*(const Request& request, const Parameters& pathParameters));
	MOCK_METHOD2(callback2, Response*(const Request& request, const Parameters& pathParameters));
	MOCK_METHOD2(callback3, Response*(const Request& request, const Parameters& pathParameters));
};
