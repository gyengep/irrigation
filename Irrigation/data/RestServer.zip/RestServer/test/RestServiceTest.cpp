#include "RestServiceTest.h"
#include "Response.h"
#include "WebServerException.h"

using ::testing::_;
using namespace std::placeholders;


void RestServiceTest::SetUp() {
	restService.addPath(MHD_HTTP_METHOD_GET, "/tom/and/jerry", std::bind(callback1, this, _1, _2));
	restService.addPath(MHD_HTTP_METHOD_DELETE, "/tom/and/jerry", std::bind(callback2, this, _1, _2));
	restService.addPath(MHD_HTTP_METHOD_POST, "/resource1/{value1}/resource2/{value2}", std::bind(callback3, this, _1, _2));
}

void RestServiceTest::TearDown() {
}


TEST_F(RestServiceTest, notFound) {
	try {
		Request request(nullptr, MHD_HTTP_VERSION_1_1, MHD_HTTP_METHOD_GET, "/123456789", Data());
		restService.onRequest(request);
		FAIL();
	} catch (WebServerException& e) {
		EXPECT_EQ(MHD_HTTP_NOT_FOUND, e.getStatusCode());
	} catch (...) {
		FAIL();
	}
}

TEST_F(RestServiceTest, methodNotAllowed) {
	try {
		Request request(nullptr, MHD_HTTP_VERSION_1_1, MHD_HTTP_METHOD_POST, "/tom/and/jerry", Data());
		restService.onRequest(request);
		FAIL();
	} catch (WebServerException& e) {
		EXPECT_EQ(MHD_HTTP_METHOD_NOT_ALLOWED, e.getStatusCode());
	} catch (...) {
		FAIL();
	}
}

TEST_F(RestServiceTest, testCallback) {
	EXPECT_CALL(*this, callback1(_, Parameters())).Times(1);

	Request request1(nullptr, MHD_HTTP_VERSION_1_1, MHD_HTTP_METHOD_GET, "/tom/and/jerry", Data());
	restService.onRequest(request1);
}

TEST_F(RestServiceTest, testParameters) {
	EXPECT_CALL(*this, callback3(_, Parameters({{"value1", "12345"}, {"value2", "ASDFG"}}))).Times(1);

	Request request1(nullptr, MHD_HTTP_VERSION_1_1, MHD_HTTP_METHOD_POST, "/resource1/12345/resource2/ASDFG", Data());
	restService.onRequest(request1);
}
