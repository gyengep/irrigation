#include "WebServerTest.h"
#include <curl/curl.h>


void WebServerTest::SetUp() {
	testWebService.reset(new TestWebService());
	webServer.reset(new WebServer(testWebService.get(), port));
}

void WebServerTest::TearDown() {
}

WebServerTest::TestWebService::TestWebService() :
	httpResponseCode(200)
{
}

Response* WebServerTest::TestWebService::onRequest(const Request& request) {
	lastRequestedUrl = request.getUrl();
	lastRequestedMethod = request.getMethod();
	lastRequestedVersion = request.getVersion();
	lastRequestedParameters = request.getRequestParameters();
	lastRequestedData = request.getUploadData();

	return new Response(httpResponse, httpResponseCode);
}

string WebServerTest::createUrl(uint16_t port, const string& path, const Parameters& parameters) {
	ostringstream o;

	o << "http://localhost:" << port;
	o << path;

	if (!parameters.empty()) {
		o << "?";

		for (auto it = parameters.begin(); it != parameters.end(); ++it) {
			if (parameters.begin() != it) {
				o << "&";
			}

			o << it->first << "=" << it->second;
		}
	}

	return o.str();
}

size_t WebServerTest::dataArrived(void* buffer, size_t size, size_t nmemb, void* ctxt) {
    const char* charBuffer = static_cast<const char*>(buffer);
    const size_t length = size * nmemb;

    DownloadDataType* data = static_cast<DownloadDataType*>(ctxt);

    if (data) {
        data->insert(data->end(), &charBuffer[0], &charBuffer[length]);
    	return length;
	} else {
		return 0;
	}
}

size_t WebServerTest::dataRequested(void* buffer, size_t size, size_t nmemb, void* ctxt) {
	UploadDataType* uploadStruct = static_cast<UploadDataType*>(ctxt);

	size_t& pos = uploadStruct->first;
	const char* message = uploadStruct->second;

	const size_t maxDataSize = size * nmemb;
	const size_t remainingDataSize = strlen(message + pos);
	const size_t uploadDataSize = min(maxDataSize, remainingDataSize);

    memcpy(buffer, message + pos, uploadDataSize);
    pos += uploadDataSize;
    return uploadDataSize;
}


TEST_F(WebServerTest, connectGET) {
	const string path = "/connect";
	const string url = createUrl(port, path, Parameters());

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(path, testWebService->lastRequestedUrl);
	EXPECT_EQ("GET", testWebService->lastRequestedMethod);
	EXPECT_EQ("HTTP/1.1", testWebService->lastRequestedVersion);
}

TEST_F(WebServerTest, connectPOST) {
	const string path = "/connectPOST";
	const string url = createUrl(port, path, Parameters());

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_POST, 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "");
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(path, testWebService->lastRequestedUrl);
	EXPECT_EQ("POST", testWebService->lastRequestedMethod);
	EXPECT_EQ("HTTP/1.1", testWebService->lastRequestedVersion);
}

TEST_F(WebServerTest, connectDELETE) {
	const string path = "/connectDELETE";
	const string url = createUrl(port, path, Parameters());

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "DELETE");
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(path, testWebService->lastRequestedUrl);
	EXPECT_EQ("DELETE", testWebService->lastRequestedMethod);
	EXPECT_EQ("HTTP/1.1", testWebService->lastRequestedVersion);
}

TEST_F(WebServerTest, resultOK) {
	const string path = "/result";
	const string url = createUrl(port, path, Parameters());

	const int httpResponseCode = 200;
	const char* httpResponse = "TEST_RESPONE";

	testWebService->httpResponse = httpResponse;
	testWebService->httpResponseCode = httpResponseCode;

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

    long receivedHttpCode = 0;
    DownloadDataType receivedData;

    if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, dataArrived);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &receivedData);
        curl_easy_perform(curl);
	    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &receivedHttpCode);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(httpResponseCode, receivedHttpCode);
	EXPECT_STREQ(httpResponse, receivedData.c_str());
}

TEST_F(WebServerTest, result404) {
	const string path = "/result";
	const string url = createUrl(port, path, Parameters());

	const int httpResponseCode = 404;
	const char* httpResponse = "NOT FOUND";

	testWebService->httpResponse = httpResponse;
	testWebService->httpResponseCode = httpResponseCode;

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

    long receivedHttpCode = 0;
    DownloadDataType receivedData;

    if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, dataArrived);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &receivedData);
        curl_easy_perform(curl);
	    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &receivedHttpCode);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(httpResponseCode, receivedHttpCode);
	EXPECT_STREQ(httpResponse, receivedData.c_str());
}

TEST_F(WebServerTest, requestParameters) {
	const string path = "/requestParameters";
	const Parameters parameters {{"name", "Tom"}, {"value", "523"}, {"project", "curl"}};
	const string url = createUrl(port, path, parameters);

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(parameters, testWebService->lastRequestedParameters);
}

TEST_F(WebServerTest, noRequestParameters) {
	const string path = "/noRequestParameters";
	const Parameters parameters;
	const string url = createUrl(port, path, parameters);

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(parameters, testWebService->lastRequestedParameters);
}

TEST_F(WebServerTest, uploadData) {
	const string path = "/uploadData";
	const string url = createUrl(port, path, Parameters());
    const string uploadData = "TEST_UPLOAD_DATA";

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);


    if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_POST, 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, uploadData.c_str());
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(Data(uploadData.begin(), uploadData.end()), testWebService->lastRequestedData);
}

TEST_F(WebServerTest, noUploadData) {
	const string path = "/noUploadData";
	const string url = createUrl(port, path, Parameters());

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);


    if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_POST, 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, "");
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(Data(), testWebService->lastRequestedData);
}

TEST_F(WebServerTest, uploadDataPATCH) {
	const string path = "/uploadDataPATCH";
	const string url = createUrl(port, path, Parameters());
    const string uploadData = "UPLOAD_DATA_PATCH";

	CURL *curl = curl_easy_init();
	ASSERT_NE(nullptr, curl);

	UploadDataType uploadStruct {0, uploadData.c_str()};


    if (curl) {
		curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
		curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PATCH");
		curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
		curl_easy_setopt(curl, CURLOPT_READFUNCTION, dataRequested);
		curl_easy_setopt(curl, CURLOPT_READDATA, &uploadStruct);
        curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}

	EXPECT_EQ(path, testWebService->lastRequestedUrl);
	EXPECT_EQ("PATCH", testWebService->lastRequestedMethod);
	EXPECT_EQ("HTTP/1.1", testWebService->lastRequestedVersion);
    EXPECT_EQ(Data(uploadData.begin(), uploadData.end()), testWebService->lastRequestedData);
}
