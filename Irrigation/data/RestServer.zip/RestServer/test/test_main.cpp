#include <gmock/gmock.h>
#include "Logger.h"


int main(int argc, char **argv) {
	LOGGER.setLevel(Logger::OFF);
	::testing::InitGoogleMock(&argc, argv);
	return RUN_ALL_TESTS();
}
