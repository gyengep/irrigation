#pragma once
#include <gtest/gtest.h>

using namespace std;


class SplitPathTest : public ::testing::Test {
protected:

    virtual void SetUp();
    virtual void TearDown();
};
